/**
  * Be careful with this file!
  * - Don't commit to repo or ftp to production it
  */

module.exports = {
  host: 'YOUR_HOST',
  user: 'YOUR_USERNAME',
  password: 'YOUR_PASSWORD',
  port: 21,
  secure: false,
  parallel: 3,
  maxConnections: 5,
};
